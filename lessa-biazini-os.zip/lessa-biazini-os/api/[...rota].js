// Função serverless da Vercel — delega para o roteador compartilhado.
const { tratarRequisicao } = require('../lib/rotas');
module.exports = (req, res) => tratarRequisicao(req, res);
