# Lessa Biazini OS

Sistema de captação, qualificação e gestão de execução para a **Lessa Biazini Gestão Empresarial** (Londrina, PR) — operacionalização técnica fiscal e previdenciária em modelo white label B2B.

## Por que este sistema (gaps identificados)

Análise do posicionamento público da empresa (site lessabiazini.com.br + Linktree/Instagram):

| Gap | Impacto | O que o sistema resolve |
|---|---|---|
| Único CTA é um link de WhatsApp | Lead chega frio, sem dado nenhum; triagem 100% manual | **Simulador público** que estima o crédito antes do contato e captura o lead já qualificado |
| Nenhuma qualificação automática | Tempo da equipe gasto igualmente em leads pequenos e grandes | **Score 0–100** com faixas de SLA (A = contato em 4h) |
| Pipeline de 6 etapas (levantamento → compensação) sem ferramenta visível | Risco de perda de prazo e retrabalho | **Kanban de execução** com trilha de auditoria por caso — coerente com a promessa de "rastreabilidade total" |
| Prazo prescricional de 60 meses corre todo mês | Cada mês de atraso = crédito que prescreve | **Alertas de prescrição** automáticos |
| Propostas white label montadas à mão | Horas por proposta | **Gerador de proposta** em HTML pronto para PDF, com a identidade do escritório parceiro |

## Rodar localmente

```bash
node server.js
# Simulador público:  http://localhost:3000/
# Painel interno:     http://localhost:3000/painel
```

Sem `DATABASE_URL`, os dados ficam em `data/db.json` (apenas desenvolvimento).

## Publicar na Vercel (com Supabase ou Neon)

1. **Crie o banco** — no [Supabase](https://supabase.com) (Project Settings → Database → Connection string, modo *Transaction pooler*) ou no [Neon](https://neon.tech). Copie a connection string Postgres.
2. **Importe o repositório na Vercel** (Add New → Project → este repo do GitHub). Framework preset: *Other*. Sem build command.
3. **Adicione a variável de ambiente** `DATABASE_URL` com a connection string e faça o deploy.

As tabelas (`registros` e `contadores`) são criadas automaticamente na primeira requisição. Verifique em `/api/saude` — deve responder `{"banco":"postgres"}`.

⚠️ O `/painel` e a API ficam públicos neste primeiro deploy. Antes de divulgar a URL, adicione autenticação (Vercel Password Protection, Supabase Auth ou um middleware simples de token).

## Arquitetura

```
server.js           servidor local de desenvolvimento
api/[...rota].js    função serverless da Vercel (mesmo roteador)
lib/rotas.js        roteador REST compartilhado
lib/calc.js         motor de estimativa de créditos + score de leads (parâmetros em PARAMS)
lib/db.js           regras de negócio: pipeline, trilha de auditoria, alertas de prescrição
lib/store.js        armazenamento: Postgres (DATABASE_URL) ou JSON local
lib/proposta.js     gerador de proposta white label (HTML)
public/             frontend responsivo (simulador + painel) com a identidade da marca
```

### API

| Rota | Função |
|---|---|
| `POST /api/simulacao` | Estimativa preliminar de créditos (memória de cálculo linha a linha) |
| `POST /api/leads` · `GET /api/leads` · `PATCH /api/leads/:id` | Captação, listagem e gestão de leads com score |
| `GET/POST /api/parceiros` | Escritórios parceiros |
| `GET/POST /api/casos` · `POST /api/casos/:id/avancar` | Pipeline com trilha de auditoria |
| `GET /api/alertas?meses=6` | Competências prescrevendo na janela informada |
| `GET /api/dashboard` | Métricas consolidadas |
| `POST /api/propostas` | Proposta white label em HTML |

## Avisos importantes

- As estimativas do simulador são **preliminares e não vinculantes** — os percentuais por verba e o fator Selic em `lib/calc.js → PARAMS` são parâmetros médios e **devem ser calibrados pela equipe técnica da Lessa Biazini** antes de uso público.
- O texto jurídico-fiscal (verbas, normativos) deve ser validado por quem domina a legislação vigente.
- A identidade visual usa as cores extraídas do logotipo oficial (navy #00183a, azul #004db3).
